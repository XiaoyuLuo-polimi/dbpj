create definer = root@`%` trigger check_procreatetion_date
    before insert
    on product
    for each row
begin

    if (date(new.product_date)<date(now()))
    then
        SIGNAL SQLSTATE 'TX000' SET MESSAGE_TEXT = "You cannot insert a POD preceding the current day.";
    end if;

    if exists(select * from product where date(new.product_date)=date(product_date))
    then
        SIGNAL SQLSTATE 'TX000' SET MESSAGE_TEXT = "There was a product of the inserted day.";
    end if;

end;

