create definer = root@`%` trigger check_procreatetion_date
    before insert
    on product
    for each row
begin
    if (date(new.product_date)<date(now()))
    then
        SIGNAL SQLSTATE 'TX000' SET MESSAGE_TEXT = "You cannot insert a POD preceding the current day";
    end if;
end;

