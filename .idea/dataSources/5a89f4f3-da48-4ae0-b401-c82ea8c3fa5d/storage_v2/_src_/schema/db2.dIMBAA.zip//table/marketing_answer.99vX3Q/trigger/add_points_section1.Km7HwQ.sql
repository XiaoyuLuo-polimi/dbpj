create definer = root@`%` trigger add_points_section1
    after insert
    on marketing_answer
    for each row
begin
    update user set points=points+1 where id=(select user_id from questionnaire where id=new.questionnaire_id);
end;

