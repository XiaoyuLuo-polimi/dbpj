create definer = root@`%` trigger qndeletion
    after update
    on questionnaire
    for each row
begin
    if old.admin_id=0 and new.admin_id>0
    then
        update user set points=points-(select count(*) from marketing_answer ma where new.id=ma.questionnaire_id)
        where id=new.user_id;
        if old.age=0 then
            update user set points=points-2 where id=new.user_id;
        end if;
        if old.sex='0' then
            update user set points=points-2 where id=new.user_id;
        end if;
        if old.expertise_level='0' then
            update user set points=points-2 where id=new.user_id;
        end if;
        delete from marketing_answer where questionnaire_id=new.id;
    end if;
end;

