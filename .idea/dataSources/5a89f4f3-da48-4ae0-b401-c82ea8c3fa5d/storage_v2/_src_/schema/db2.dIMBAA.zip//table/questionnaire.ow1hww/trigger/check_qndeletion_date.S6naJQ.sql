create definer = root@`%` trigger check_qndeletion_date
    before update
    on questionnaire
    for each row
begin
    if old.admin_id is null and new.admin_id is not null and old.create_time>=date(now())
    then
        SIGNAL SQLSTATE 'TX000' SET MESSAGE_TEXT = "You cannot delete a questionnaire which create time is the posterior of today.";
    end if;
end;

