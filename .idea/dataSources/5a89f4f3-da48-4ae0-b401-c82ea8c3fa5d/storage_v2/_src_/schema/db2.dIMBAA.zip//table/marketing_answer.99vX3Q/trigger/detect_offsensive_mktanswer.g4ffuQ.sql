create definer = root@`%` trigger detect_offsensive_mktanswer
    before insert
    on marketing_answer
    for each row
begin
    if exists(select * from offensive_word where locate(word,new.answer)>0)
    then
        SIGNAL SQLSTATE 'TX000' SET MESSAGE_TEXT = "There are offensive words in the user's answers.";
    end if;
end;

