create definer = root@`%` trigger hasBeenBlocked
    before insert
    on questionnaire
    for each row
begin
        if (select isblocked from user where id=new.user_id)=1
            then
                SIGNAL SQLSTATE 'TX000' SET MESSAGE_TEXT = "This user has been blocked.";
        end if;
    end;

