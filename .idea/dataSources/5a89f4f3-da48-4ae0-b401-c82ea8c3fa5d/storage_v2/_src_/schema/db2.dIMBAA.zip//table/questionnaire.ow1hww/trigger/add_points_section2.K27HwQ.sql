create definer = root@`%` trigger add_points_section2
    after insert
    on questionnaire
    for each row
begin
    if new.iscancelled=0
    then

        if new.age>0  then
            update user set points=points+2 where id=new.user_id;
        end if;

        if new.sex!='0' then
            update user set points=points+2 where id=new.user_id;
        end if;

        if new.expertise_level!='0' then
            update user set points=points+2 where id=new.user_id;
        end if;

    end if;
end;

